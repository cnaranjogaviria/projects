Nombre del proyecto: 
Test1

Objetivo del proyecto: 
Verificar el correcto funcionamiento de la pagina web https://www.saucedemo.com/

Elaborado por: 
Claudia Cecilia Naranjo Gaviria

Plataforma: 
Katalon

Enlace de descarga de Katalon: https://www.katalon.com/
Luego de instalada la aplicación proceda con la importación y apertura del proyecto (Test1).


Contenido del proyecto:

*Test Cases:
**Compra_General
**Compra_Menor_Mayor_Producto (solicitado en el punto 3 del documento 'prueba técnica')
**Login
**Login_bloqueado

*Object Repository
**Page_Swag Labs

*Test Suites
**Escenarios definidos
***Verificar el proceso de login en la aplicación
***Verificar el proceso de login en la aplicación_1
***Verificar el proceso de pago de productos
***Verificar la adición de productos al carrito de compras

*Reports:
**20210526_223126
**20210526_231846

*Test Runs

*Ejecución del proyecto:
Se presentan dos opciones:

*Opción 1:
**Dar doble clic sobre el test cases a ejecutar 
**Dar clic en el botón Run ubicado en el menú superior

*Opción 2:
**En Test Suites se encuentra el folder Run All Test Suites
**Doble clic sobre el
**Clic en el botón Execute